window.onload=initfunction;

var required=["Enter your first name", 
            "Enter your last name",
            "Enter your address, including the city", 
            "Enter your phone number", 
            "Enter your email address", 
            "Enter your Postal Code",
            "Enter your Age",
            "Enter your Income",
            ""];

var displayRequired;
function initfunction() {
    displayRequired=document.getElementById("required");
    createListeners(document.getElementById("firstname"),0);
    createListeners(document.getElementById("lastname"),1);
    createListeners(document.getElementById("address"),2);
    createListeners(document.getElementById("phone"),3);
    createListeners(document.getElementById("email"),4)
    createListeners(document.getElementById("postalcode"),5);
    createListeners(document.getElementById("age"),6);
    createListeners(document.getElementById("income"),7)

}

function createListeners(inputobject,number) {
	inputobject.addEventListener("focus",function () {displayRequired.innerHTML=required[number];},false);
	inputobject.addEventListener("blur",function () {displayRequired.innerHTML=required[8];},false);
	
}

    var own = document.getElementById("input[name=own]:checked").value;


    if (document.querySelector("input[name=vehicle]:checked")){
      client.asset.push("Vehicle")
    }
    if (document.querySelector("input[name=rrps]:checked")) {
        client.asset.push("RRPS");
      }
      if (document.querySelector("input[name=tfsa]:checked")) {
        client.asset.push("TFSA");
      }
      if (document.querySelector("input[name=rrif]:checked")) {
        client.asset.push("RRIF");
      }
    client.asset.push("own");
    



      
var objectArray = [];
var clientAssets = [];
var index = 0;
for (var i = 0; i < objectarray.length; i++) {
function addClients(){
    var client = {
        firstname,
        lastname,
        address,
        postalcode,
        email,
        phone,
        age,
        annual,
        info:[],
        assets: []
    }
    client = objectarray[i];
    clientlist =
      client.firstname +
      "," +
      client.lastname +
      "," +
      client.address +
      "," +
      client.postalcode +
      client.email + "," +
      client.phone + "," +
      client.annual;

        for (var x = 0; x < client.info.length; x++) {
          client += client.info[x] + " ";
        }
        for (var x = 0; x < client.asset.length; x++) {
          client += client.asset[x]  + " ";
        }
    
        //create radio button tags and elements
        displayRadiobuttons += "<input type=radio name=listitem ";
        displayRadiobuttons += " value=" + i + " ";
        displayRadiobuttons += " onchange=modifyItem(this.value)>";
        displayRadiobuttons += client + "<br>";
      }
      //display list
      document.getElementById("print").innerHTML = displayRadiobuttons;
    }


function editItem(i) {
  index = i;
  var dataItem;
  var client = {
    firstname,
    lastname,
    address,
    postalcode,
    email,
    phone,
    age,
    annual,
    info:[],
    assets: []
}
client = objectarray[i];
document.getElementById("submit").disabled = true;
document.getElementById("edit").disabled = false;
document.getElementById("firstname").value=client.firstname;
document.getElementById("lastname").value=client.lastname;
document.getElementById("address").value=client.address;
document.getElementById("postalcode").value=client.postalcode;
document.getElementById("phone").value=client.phone;
document.getElementById("email").value=client.email;
document.getElementById("annual").value=client.annual;


document.register.vehicle = false;
document.register.rrsp = false;
document.register.tfsa = false;
document.register.rrif = false;

if (client.asset.length > 0){
  for (var i=0; i<client.asset.length; i++) {
    dataItem = client.asset[i];
    if (dataItem == "vehicle") {
      document.register.vehicle.checked = true;
    }
    if (dataItem == "rrsp") {
      document.register.rrps.checked = true;
  }
  if (dataItem == "tfsa") {
    document.register.tfsa.checked = true;
}
  if (dataItem == "rrif") {
    document.register.rrif.checked = true;
}

}
}
}

function setClientData(){
  index = i;
  var dataItem;
  var client = {
    firstname,
    lastname,
    address,
    postalcode,
    email,
    phone,
    age,
    annual,
    info:[],
    assets: []
}
client = objectarray[i];
document.getElementById("submit").disabled = true;
document.getElementById("edit").disabled = false;
document.getElementById("firstname").value=client.firstname;
document.getElementById("lastname").value=client.lastname;
document.getElementById("address").value=client.address;
document.getElementById("postalcode").value=client.postalcode;
document.getElementById("phone").value=client.phone;
document.getElementById("email").value=client.email;
document.getElementById("annual").value=client.annual;

var own = document.querySelector("input[name=own]:checked");

client.info.push(own);
if (dataItem == "vehicle") {
  document.register.vehicle.checked = true;
}
if (dataItem == "rrsp") {
  document.register.rrps.checked = true;
}
if (dataItem == "tfsa") {
document.register.tfsa.checked = true;
}
if (dataItem == "rrif") {
document.register.rrif.checked = true;
}

objectarray[index]=client;
document.getElementById("submit").disabled = false;
document.getElementById("edit").disabled = true;
}

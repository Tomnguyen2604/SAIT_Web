<?php

$my_t=getdate(date("U"));
print("$my_t[hours]:$my_t[minutes]");
?>
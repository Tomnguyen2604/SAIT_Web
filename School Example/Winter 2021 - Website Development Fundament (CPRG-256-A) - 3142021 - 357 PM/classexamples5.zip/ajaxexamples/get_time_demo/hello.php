<!-- example for PHP 5.0.0 final release -->

<html>

<?php echo( "<h1>Hello World</h1>" ); ?>

</html>
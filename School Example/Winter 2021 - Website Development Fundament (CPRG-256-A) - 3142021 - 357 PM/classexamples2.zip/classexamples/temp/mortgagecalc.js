/*mortgagecalc.js*/
function calcmortgage() {
	
	/*get values from form*/
	
	/*parse the numbers to double or int*/
	
	/*modify rate for monthly amount*/
	
	/*calculate number of months*/
	
	/*mortgage calculation*/
	
	
	alert("Your Monthly mortgage payment is: "+payment);

}
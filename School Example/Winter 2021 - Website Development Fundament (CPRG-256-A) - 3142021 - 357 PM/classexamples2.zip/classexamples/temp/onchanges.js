/*onchanges.js*/

function convertImperialValue(val) {
	//converts feet to cm
	var cm=parseFloat(0);
	cm=val*12*2.54;
	//display in metric number field
	document.getElementById("metric").value=cm.toFixed(2);
}

function convertMetricValue(val) {
	//converts cm to feet
	var feet=parseFloat(0);
	feet=val*0.0328;
	document.getElementById("imperial").value=feet.toFixed(2);
	
}

